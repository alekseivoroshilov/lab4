# Building
```bash
./gradlew build
```
JAR file will be created in `build/libs/biblib.jar`

Note that there are 2 failing test. Add the test method body or use `./gradlew assemble` instead.